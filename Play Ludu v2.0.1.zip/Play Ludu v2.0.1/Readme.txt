Please run this program by double-clicking the 'Play.bat' file (in Windows systems). 
Your monitor must support at least 800 X 600 pixels resolution to play the game. 
Please set your monitor resolution to 800 X 600 pixels before playing the game.